SBIT-2E Group 2 Project in Software Engineering 
InternshipManagementSystem
